from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from agent.detector import ConflictDetectionAgent
from agent.utils import extract_text
from agent.billing import FlexpriceClient

app = Flask(__name__)
CORS(app)  # Enable Cross-Origin Resource Sharing for React frontend

agent = ConflictDetectionAgent()
billing_client = FlexpriceClient()

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/api/analyze', methods=['POST'])
def analyze_documents():
    if 'files' not in request.files:
        return jsonify({"error": "No files part in the request"}), 400

    files = request.files.getlist('files')
    if not files or files[0].filename == '':
        return jsonify({"error": "No files selected"}), 400

    documents = {}
    for file in files:
        # Save files temporarily (optional, but good practice)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)
        
        # Re-open to pass stream to extractor
        with open(filepath, 'rb') as f:
            text = extract_text(f, file.filename)
            if text:
                documents[file.filename] = text

    if not documents:
        return jsonify({"error": "Could not read any of the uploaded files."}), 400

    contradictions = agent.find_contradictions(documents)
    credits_used = billing_client.charge_for_docs(len(documents))

    return jsonify({
        "contradictions": contradictions,
        "usage": {
            "docs_analyzed": len(documents),
            "credits_used": credits_used
        }
    })

@app.route('/api/status', methods=['GET'])
def status():
    return jsonify({"status": "Backend is running"}), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)