import React from 'react';
import { motion } from 'framer-motion';

function ResultsDisplay({ results }) {
  if (!results) {
    return (
      <div className="results-display">
        <h2>2. Analysis Results</h2>
        <div className="no-results">
          <p>Results will be displayed here after analysis.</p>
        </div>
      </div>
    );
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
    },
  };

  return (
    <div className="results-display">
      <h2>2. Analysis Results</h2>
      {results.contradictions.length === 0 ? (
        <motion.div
          className="no-results"
          style={{ backgroundColor: '#e8f5e9', color: '#2e7d32' }}
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <p>✅ No contradictions found based on the current rules.</p>
        </motion.div>
      ) : (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {results.contradictions.map((conflict, index) => (
            <motion.div key={index} className="conflict-card" variants={itemVariants}>
              <h3>🚨 Conflict: {conflict.type}</h3>
              {conflict.conflicting_docs.map((doc, docIndex) => (
                <div key={docIndex} className="conflict-doc">
                  <strong>In `{doc.source}`:</strong>
                  <p>Found value: <em>"{doc.value}"</em></p>
                  <p><small>Context: "{doc.context}"</small></p>
                </div>
              ))}
              <p className="suggestion"><strong>Suggestion:</strong> {conflict.suggestion}</p>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}

export default ResultsDisplay;