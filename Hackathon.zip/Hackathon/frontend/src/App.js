import React, { useState } from 'react';
import axios from 'axios';
import './App.css';
import FileUploader from './components/FileUploader';
import ResultsDisplay from './components/ResultsDisplay';
import UsageTracker from './components/UsageTracker';
import { motion } from 'framer-motion';

// The URL of your running Flask backend
const API_URL = 'http://127.0.0.1:5000';

function App() {
  const [results, setResults] = useState(null);
  const [usage, setUsage] = useState({ docs_analyzed: 0, credits_used: 0 });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAnalyze = async (files) => {
    setIsLoading(true);
    setError('');
    setResults(null);

    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });

    try {
      const response = await axios.post(`${API_URL}/api/analyze`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setResults(response.data);
      setUsage(response.data.usage);
    } catch (err) {
      setError('Failed to analyze documents. Please ensure the backend server is running and accessible.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="App">
      <header>
        <h1>📄 Smart Doc Checker Agent</h1>
        <p>Automatically find contradictions in your rules, contracts, and policies.</p>
      </header>

      <div className="main-content">
        <div className="left-panel">
          <FileUploader onAnalyze={handleAnalyze} isLoading={isLoading} />
          <UsageTracker usage={usage} />
        </div>
        <div className="right-panel">
          {isLoading && (
            <motion.div
              className="loading-spinner"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <motion.div
                className="spinner"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              ></motion.div>
              Agent is analyzing...
            </motion.div>
          )}
          {error && <div className="error-message">{error}</div>}
          <ResultsDisplay results={results} />
        </div>
      </div>
    </div>
  );
}

export default App;