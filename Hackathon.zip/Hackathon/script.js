const fileInput = document.getElementById("fileInput");
const fileList = document.getElementById("fileList");
const analyzeBtn = document.getElementById("analyzeBtn");
const highlightsDiv = document.getElementById("highlights");
const generateReportBtn = document.getElementById("generateReportBtn");
const reportOutput = document.getElementById("reportOutput");
const docsCount = document.getElementById("docsCount");
const reportsCount = document.getElementById("reportsCount");
const billingLog = document.getElementById("billingLog");
const mockUpdateBtn = document.getElementById("mockUpdateBtn");
const updateList = document.getElementById("updateList");

let selectedFiles = [];
let usage = { docsChecked: 0, reportsGenerated: 0 };

fileInput.addEventListener("change", (e) => {
  selectedFiles = Array.from(e.target.files).slice(0, 3);
  renderFileList();
});

function renderFileList() {
  fileList.innerHTML = "";
  selectedFiles.forEach((file, idx) => {
    const li = document.createElement("li");
    li.className = "file-item";
    li.innerHTML = `
      <span>${file.name} (${Math.round(file.size/1024)} KB)</span>
      <button class="btn btn-danger" onclick="removeFile(${idx})">Remove</button>
    `;
    fileList.appendChild(li);
  });
}

function removeFile(idx) {
  selectedFiles.splice(idx, 1);
  renderFileList();
}

analyzeBtn.addEventListener("click", () => {
  if (selectedFiles.length === 0) {
    alert("Please upload at least one document.");
    return;
  }
  usage.docsChecked += selectedFiles.length;
  docsCount.textContent = usage.docsChecked;

  highlightsDiv.innerHTML = "";
  selectedFiles.forEach(file => {
    const div = document.createElement("div");
    div.innerHTML = `<strong>Conflict in ${file.name}:</strong> 
      Found rule mismatch. Suggest clarifying deadlines.`;
    highlightsDiv.appendChild(div);
  });

  logBilling("per_doc", selectedFiles.length * 0.5);
});

generateReportBtn.addEventListener("click", () => {
  usage.reportsGenerated++;
  reportsCount.textContent = usage.reportsGenerated;

  reportOutput.textContent = "Report generated: Found 2 contradictions, suggested clarifications.";
  logBilling("per_report", 1.0);
});

function logBilling(type, amount) {
  const li = document.createElement("li");
  li.textContent = `${new Date().toLocaleTimeString()} - ${type} billed: $${amount.toFixed(2)}`;
  billingLog.prepend(li);
}

mockUpdateBtn.addEventListener("click", () => {
  const update = `Policy page updated at ${new Date().toLocaleTimeString()}`;
  const li = document.createElement("li");
  li.textContent = update;
  updateList.prepend(li);

  // Auto trigger conflict detection
  highlightsDiv.innerHTML = `<div><strong>External Update Conflict:</strong> New policy contradicts existing rules.</div>`;
});
