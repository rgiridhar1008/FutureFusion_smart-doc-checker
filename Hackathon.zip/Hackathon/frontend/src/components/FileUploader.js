import React, { useState } from 'react';
import { motion } from 'framer-motion';

function FileUploader({ onAnalyze, isLoading }) {
  const [files, setFiles] = useState([]);

  const handleFileChange = (event) => {
    setFiles([...event.target.files]);
  };

  const handleAnalyzeClick = () => {
    if (files.length > 0) {
      onAnalyze(files);
    }
  };

  return (
    <div className="file-uploader">
      <h3>1. Upload Documents</h3>
      <p>Select 2 or more documents (PDF, DOCX, TXT) to check for conflicts.</p>
      <input type="file" multiple onChange={handleFileChange} />
      <div style={{ marginTop: '20px' }}>
        <button
          className="upload-button"
          onClick={handleAnalyzeClick}
          disabled={files.length < 2 || isLoading}
        >
          {isLoading ? 'Analyzing...' : 'Analyze for Contradictions'}
        </button>
      </div>
    </div>
  );
}

export default FileUploader;