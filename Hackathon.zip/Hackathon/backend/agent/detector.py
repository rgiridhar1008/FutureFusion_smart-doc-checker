import re
from collections import defaultdict
from agent.suggester import SuggestionAgent

class ConflictDetectionAgent:
    """The core agent that scans documents for contradictions."""
    RULES = {
        "deadline": r"(deadline|submit before|due by|submission is)\s*:?\s*([0-9]{1,2}\s*(?:PM|AM|pm|am)|midnight|noon)",
        "attendance": r"(attendance required|minimum attendance|attendance policy)\s*:?\s*([0-9]{2,3}\s*%)",
        "notice_period": r"(notice period|resignation notice)\s*:?\s*(is|of)\s*([0-9]+\s*(?:week|weeks|month|months))"
    }

    def __init__(self):
        self.suggester = SuggestionAgent()

    def find_contradictions(self, documents: dict):
        extracted_entities = self._extract_entities(documents)
        return self._identify_conflicts(extracted_entities)

    def _extract_entities(self, documents: dict):
        all_entities = []
        for filename, text in documents.items():
            for rule_type, pattern in self.RULES.items():
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    value = match.groups()[-1].strip()
                    all_entities.append({
                        "source": filename,
                        "type": rule_type,
                        "value": value.lower(),
                        "context": match.group(0)
                    })
        return all_entities

    def _identify_conflicts(self, entities: list):
        contradictions = []
        grouped_entities = defaultdict(list)
        for entity in entities:
            grouped_entities[entity['type']].append(entity)

        for entity_type, entity_list in grouped_entities.items():
            if len(entity_list) > 1:
                first_value = entity_list[0]['value']
                is_conflict = any(e['value'] != first_value for e in entity_list)
                if is_conflict:
                    contradictions.append({
                        "type": entity_type.replace('_', ' ').capitalize(),
                        "conflicting_docs": entity_list,
                        "suggestion": self.suggester.generate_suggestion(entity_type, entity_list)
                    })
        return contradictions