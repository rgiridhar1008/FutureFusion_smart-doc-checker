class SuggestionAgent:
    """Generates intelligent suggestions to resolve detected conflicts."""
    def generate_suggestion(self, entity_type: str, entities: list):
        values = {f"'{e['value']}' (from {e['source']})" for e in entities}
        if entity_type == "deadline":
            return f"Multiple deadlines found: {', '.join(values)}. Recommend aligning to a single, consistent deadline for clarity."
        elif entity_type == "attendance":
            return f"Conflicting attendance policies found: {', '.join(values)}. Recommend defining a single, official percentage in the main handbook."
        elif entity_type == "notice_period":
            return f"Notice periods do not match: {', '.join(values)}. The employment contract usually overrides other documents, but this should be clarified by HR."
        else:
            return f"Conflicting values found: {', '.join(values)}. Please ensure consistency across all documents."