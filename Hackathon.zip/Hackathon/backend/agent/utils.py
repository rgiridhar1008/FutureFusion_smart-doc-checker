import PyPDF2
import docx
import re

def extract_text(file_stream, file_name: str):
    """Extracts plain text from a file stream and cleans it."""
    try:
        extension = file_name.split('.')[-1].lower()
        text = ""
        if extension == 'pdf':
            pdf_reader = PyPDF2.PdfReader(file_stream)
            text = "".join(page.extract_text() for page in pdf_reader.pages if page.extract_text())
        elif extension == 'docx':
            doc = docx.Document(file_stream)
            text = "\n".join([para.text for para in doc.paragraphs])
        elif extension == 'txt':
            text = file_stream.read().decode("utf-8")
        else:
            return None

        # Normalize whitespace and clean up text
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    except Exception as e:
        print(f"Error processing file {file_name}: {e}")
        return f"Could not read file: {file_name}."