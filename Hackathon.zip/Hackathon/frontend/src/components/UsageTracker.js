import React from 'react';

function UsageTracker({ usage }) {
  return (
    <div className="usage-tracker">
      <h3>Flexprice Usage</h3>
      <div className="usage-metric">
        <span>Documents Analyzed</span>
        <strong>{usage.docs_analyzed}</strong>
      </div>
      <div className="usage-metric">
        <span>Credits Used</span>
        <strong>{usage.credits_used}</strong>
      </div>
    </div>
  );
}

export default UsageTracker;