class FlexpriceClient:
    """A mock client to simulate interactions with the Flexprice billing API."""
    COST_PER_DOC = 1
    COST_PER_REPORT = 2

    def charge_for_docs(self, doc_count: int):
        """Simulates charging for analyzing documents."""
        if doc_count <= 0:
            return 0
        cost = doc_count * self.COST_PER_DOC
        print(f"[FLEXPRICE API CALL] Charging {cost} credits for analyzing {doc_count} document(s).")
        return cost

    def charge_for_report(self):
        """Simulates charging for generating one report."""
        cost = self.COST_PER_REPORT
        print(f"[FLEXPRICE API CALL] Charging {cost} credits for generating 1 report.")
        return cost